﻿using System;
using LostMyLighterGroup4.MenuClasses;
using System.Collections.Generic;

namespace LostMyLighterGroup4
{

    class Program
    {
        static void Main(string[] args)
        {
            ProgramManager pMan = new ProgramManager();
            pMan.Presenter();
        }
    }

}
